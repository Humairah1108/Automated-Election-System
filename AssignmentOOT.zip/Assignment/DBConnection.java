import java.sql.*;
public class DBConnection {
    public static Connection conn;
}
